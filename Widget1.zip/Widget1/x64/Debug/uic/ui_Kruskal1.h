/********************************************************************************
** Form generated from reading UI file 'Kruskal1.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KRUSKAL1_H
#define UI_KRUSKAL1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Kruskal1Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Kruskal1Class)
    {
        if (Kruskal1Class->objectName().isEmpty())
            Kruskal1Class->setObjectName(QString::fromUtf8("Kruskal1Class"));
        Kruskal1Class->resize(600, 400);
        menuBar = new QMenuBar(Kruskal1Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        Kruskal1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Kruskal1Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        Kruskal1Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(Kruskal1Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        Kruskal1Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(Kruskal1Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        Kruskal1Class->setStatusBar(statusBar);

        retranslateUi(Kruskal1Class);

        QMetaObject::connectSlotsByName(Kruskal1Class);
    } // setupUi

    void retranslateUi(QMainWindow *Kruskal1Class)
    {
        Kruskal1Class->setWindowTitle(QCoreApplication::translate("Kruskal1Class", "Kruskal1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Kruskal1Class: public Ui_Kruskal1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KRUSKAL1_H
