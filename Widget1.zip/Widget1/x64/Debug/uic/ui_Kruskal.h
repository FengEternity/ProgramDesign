/********************************************************************************
** Form generated from reading UI file 'Kruskal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KRUSKAL_H
#define UI_KRUSKAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_KruskalClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *KruskalClass)
    {
        if (KruskalClass->objectName().isEmpty())
            KruskalClass->setObjectName(QString::fromUtf8("KruskalClass"));
        KruskalClass->resize(600, 400);
        menuBar = new QMenuBar(KruskalClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        KruskalClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(KruskalClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        KruskalClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(KruskalClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        KruskalClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(KruskalClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        KruskalClass->setStatusBar(statusBar);

        retranslateUi(KruskalClass);

        QMetaObject::connectSlotsByName(KruskalClass);
    } // setupUi

    void retranslateUi(QMainWindow *KruskalClass)
    {
        KruskalClass->setWindowTitle(QCoreApplication::translate("KruskalClass", "Kruskal", nullptr));
    } // retranslateUi

};

namespace Ui {
    class KruskalClass: public Ui_KruskalClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KRUSKAL_H
