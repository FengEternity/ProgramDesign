/********************************************************************************
** Form generated from reading UI file 'Widget1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET1_H
#define UI_WIDGET1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget1Class
{
public:
    QWidget *centralWidget;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_2;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *horizontalSpacer_6;
    QCheckBox *checkBox;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_4;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer_3;

    void setupUi(QMainWindow *Widget1Class)
    {
        if (Widget1Class->objectName().isEmpty())
            Widget1Class->setObjectName(QStringLiteral("Widget1Class"));
        Widget1Class->resize(600, 400);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Widget1Class->sizePolicy().hasHeightForWidth());
        Widget1Class->setSizePolicy(sizePolicy);
        Widget1Class->setMinimumSize(QSize(600, 400));
        Widget1Class->setMaximumSize(QSize(600, 400));
        Widget1Class->setStyleSheet(QStringLiteral(""));
        centralWidget = new QWidget(Widget1Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget_2 = new QWidget(centralWidget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(80, 70, 441, 241));
        QFont font;
        font.setUnderline(false);
        widget_2->setFont(font);
        verticalLayout = new QVBoxLayout(widget_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        widget = new QWidget(widget_2);
        widget->setObjectName(QStringLiteral("widget"));
        gridLayout = new QGridLayout(widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        QFont font1;
        font1.setPointSize(12);
        lineEdit_2->setFont(font1);
        lineEdit_2->setLayoutDirection(Qt::LeftToRight);
        lineEdit_2->setMaxLength(16);
        lineEdit_2->setEchoMode(QLineEdit::Password);
        lineEdit_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEdit_2->setCursorMoveStyle(Qt::LogicalMoveStyle);
        lineEdit_2->setClearButtonEnabled(false);

        gridLayout->addWidget(lineEdit_2, 2, 3, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_5, 1, 0, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_6, 1, 4, 1, 1);

        checkBox = new QCheckBox(widget);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setUnderline(false);
        font2.setWeight(75);
        checkBox->setFont(font2);
        checkBox->setStyleSheet(QStringLiteral("color:rgb(255, 0, 0)"));

        gridLayout->addWidget(checkBox, 2, 4, 1, 1);

        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        QFont font3;
        font3.setFamily(QStringLiteral("Arial"));
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setItalic(false);
        font3.setUnderline(false);
        font3.setWeight(75);
        label->setFont(font3);
        label->setMouseTracking(false);
        label->setStyleSheet(QStringLiteral("color:rgb(0, 0, 255)"));

        gridLayout->addWidget(label, 1, 1, 1, 1);

        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setFont(font1);
        lineEdit->setAlignment(Qt::AlignCenter);
        lineEdit->setReadOnly(true);

        gridLayout->addWidget(lineEdit, 1, 3, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font4;
        font4.setPointSize(12);
        font4.setBold(true);
        font4.setUnderline(false);
        font4.setWeight(75);
        label_2->setFont(font4);
        label_2->setStyleSheet(QStringLiteral("color:rgb(0,0,255)"));

        gridLayout->addWidget(label_2, 2, 1, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 1, 2, 1, 1);


        verticalLayout->addWidget(widget);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        horizontalLayout = new QHBoxLayout(widget_3);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        pushButton = new QPushButton(widget_3);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setFont(font4);
        pushButton->setStyleSheet(QStringLiteral("background-color:rgb(152,245,255)"));
        pushButton->setAutoDefault(true);
        pushButton->setFlat(false);

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_2 = new QPushButton(widget_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font4);
        pushButton_2->setStyleSheet(QStringLiteral("background-color:rgb(152,245,255)"));

        horizontalLayout->addWidget(pushButton_2);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addWidget(widget_3);

        Widget1Class->setCentralWidget(centralWidget);

        retranslateUi(Widget1Class);

        pushButton->setDefault(true);


        QMetaObject::connectSlotsByName(Widget1Class);
    } // setupUi

    void retranslateUi(QMainWindow *Widget1Class)
    {
        Widget1Class->setWindowTitle(QApplication::translate("Widget1Class", "\346\254\242\350\277\216\344\275\277\347\224\250\345\215\227\344\272\254\351\203\275\345\270\202\345\234\210\344\277\241\346\201\257\346\237\245\350\257\242\345\217\212\350\256\241\347\256\227\347\263\273\347\273\237\357\274\201", Q_NULLPTR));
        lineEdit_2->setPlaceholderText(QApplication::translate("Widget1Class", "\345\217\252\345\205\201\350\256\270\346\225\260\345\255\227\345\222\214\345\255\227\346\257\215", Q_NULLPTR));
        checkBox->setText(QApplication::translate("Widget1Class", "\345\217\257\350\247\201", Q_NULLPTR));
        label->setText(QApplication::translate("Widget1Class", "\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        label_2->setText(QApplication::translate("Widget1Class", "\345\257\206  \347\240\201", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Widget1Class", "\347\231\273\345\275\225", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Widget1Class", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget1Class: public Ui_Widget1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET1_H
