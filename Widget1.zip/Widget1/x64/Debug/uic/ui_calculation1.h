/********************************************************************************
** Form generated from reading UI file 'calculation1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALCULATION1_H
#define UI_CALCULATION1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_calculation1Class
{
public:
    QWidget *centralWidget;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton;

    void setupUi(QMainWindow *calculation1Class)
    {
        if (calculation1Class->objectName().isEmpty())
            calculation1Class->setObjectName(QStringLiteral("calculation1Class"));
        calculation1Class->resize(564, 454);
        calculation1Class->setMinimumSize(QSize(564, 454));
        calculation1Class->setMaximumSize(QSize(564, 454));
        centralWidget = new QWidget(calculation1Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(110, 40, 331, 371));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        QFont font;
        font.setPointSize(12);
        pushButton_2->setFont(font);

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setFont(font);

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setFont(font);

        verticalLayout->addWidget(pushButton_4);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setFont(font);

        verticalLayout->addWidget(pushButton);

        calculation1Class->setCentralWidget(centralWidget);

        retranslateUi(calculation1Class);

        QMetaObject::connectSlotsByName(calculation1Class);
    } // setupUi

    void retranslateUi(QMainWindow *calculation1Class)
    {
        calculation1Class->setWindowTitle(QApplication::translate("calculation1Class", "\350\256\241\347\256\227\351\241\265\351\235\242", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("calculation1Class", "Kruskal\350\256\241\347\256\227\346\234\200\345\260\217\344\273\243\344\273\267\347\224\237\346\210\220\346\240\221", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("calculation1Class", "Floyd\347\256\227\346\263\225\346\261\202\346\234\200\347\237\255\350\267\257\345\276\204", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("calculation1Class", "\351\201\227\344\274\240\347\256\227\346\263\225\346\261\202\346\234\200\345\244\247\350\246\206\347\233\226\347\216\207", Q_NULLPTR));
        pushButton->setText(QApplication::translate("calculation1Class", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class calculation1Class: public Ui_calculation1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALCULATION1_H
