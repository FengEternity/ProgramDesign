/********************************************************************************
** Form generated from reading UI file 'enter1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTER1_H
#define UI_ENTER1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_enter1Class
{
public:
    QWidget *centralWidget;
    QListWidget *listWidget;
    QLabel *label;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton;

    void setupUi(QMainWindow *enter1Class)
    {
        if (enter1Class->objectName().isEmpty())
            enter1Class->setObjectName(QStringLiteral("enter1Class"));
        enter1Class->resize(741, 704);
        centralWidget = new QWidget(enter1Class);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        listWidget = new QListWidget(centralWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(30, 60, 131, 351));
        QFont font;
        font.setPointSize(12);
        listWidget->setFont(font);
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(250, 50, 431, 531));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(20, 470, 138, 105));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font);

        verticalLayout->addWidget(pushButton_2);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setFont(font);

        verticalLayout->addWidget(pushButton);

        enter1Class->setCentralWidget(centralWidget);

        retranslateUi(enter1Class);

        QMetaObject::connectSlotsByName(enter1Class);
    } // setupUi

    void retranslateUi(QMainWindow *enter1Class)
    {
        enter1Class->setWindowTitle(QApplication::translate("enter1Class", "\351\203\275\345\270\202\345\234\210\346\234\200\345\260\217\344\273\243\344\273\267\347\224\237\346\210\220\346\240\221", Q_NULLPTR));

        const bool __sortingEnabled = listWidget->isSortingEnabled();
        listWidget->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("enter1Class", "0 \345\215\227\344\272\254", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem1 = listWidget->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("enter1Class", "1 \351\225\207\346\261\237", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem2 = listWidget->item(2);
        ___qlistwidgetitem2->setText(QApplication::translate("enter1Class", "2 \346\211\254\345\267\236", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem3 = listWidget->item(3);
        ___qlistwidgetitem3->setText(QApplication::translate("enter1Class", "3 \346\267\256\345\256\211", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem4 = listWidget->item(4);
        ___qlistwidgetitem4->setText(QApplication::translate("enter1Class", "4 \351\251\254\351\236\215\345\261\261", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem5 = listWidget->item(5);
        ___qlistwidgetitem5->setText(QApplication::translate("enter1Class", "5 \346\273\201\345\267\236", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem6 = listWidget->item(6);
        ___qlistwidgetitem6->setText(QApplication::translate("enter1Class", "6 \350\212\234\346\271\226", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem7 = listWidget->item(7);
        ___qlistwidgetitem7->setText(QApplication::translate("enter1Class", "7 \345\256\243\345\237\216", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem8 = listWidget->item(8);
        ___qlistwidgetitem8->setText(QApplication::translate("enter1Class", "8 \346\272\247\351\230\263", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem9 = listWidget->item(9);
        ___qlistwidgetitem9->setText(QApplication::translate("enter1Class", "9 \351\207\221\345\235\233", Q_NULLPTR));
        listWidget->setSortingEnabled(__sortingEnabled);

        label->setText(QString());
        pushButton_2->setText(QApplication::translate("enter1Class", "\345\257\274\345\207\272", Q_NULLPTR));
        pushButton->setText(QApplication::translate("enter1Class", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class enter1Class: public Ui_enter1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTER1_H
