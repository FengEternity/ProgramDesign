/********************************************************************************
** Form generated from reading UI file 'inheritance1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INHERITANCE1_H
#define UI_INHERITANCE1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_inheritance1Class
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget_2;
    QGridLayout *gridLayout;
    QTextEdit *textEdit;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *startButton;
    QPushButton *checkButton;
    QPushButton *outButton;
    QPushButton *backButton;
    QLabel *label;

    void setupUi(QWidget *inheritance1Class)
    {
        if (inheritance1Class->objectName().isEmpty())
            inheritance1Class->setObjectName(QStringLiteral("inheritance1Class"));
        inheritance1Class->resize(657, 656);
        verticalLayout = new QVBoxLayout(inheritance1Class);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        widget_2 = new QWidget(inheritance1Class);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        gridLayout = new QGridLayout(widget_2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        textEdit = new QTextEdit(widget_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        QFont font;
        font.setPointSize(13);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);

        gridLayout->addWidget(textEdit, 1, 0, 1, 1);

        widget = new QWidget(widget_2);
        widget->setObjectName(QStringLiteral("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        startButton = new QPushButton(widget);
        startButton->setObjectName(QStringLiteral("startButton"));

        horizontalLayout->addWidget(startButton);

        checkButton = new QPushButton(widget);
        checkButton->setObjectName(QStringLiteral("checkButton"));

        horizontalLayout->addWidget(checkButton);

        outButton = new QPushButton(widget);
        outButton->setObjectName(QStringLiteral("outButton"));

        horizontalLayout->addWidget(outButton);

        backButton = new QPushButton(widget);
        backButton->setObjectName(QStringLiteral("backButton"));

        horizontalLayout->addWidget(backButton);


        gridLayout->addWidget(widget, 2, 0, 1, 1);

        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);


        verticalLayout->addWidget(widget_2);


        retranslateUi(inheritance1Class);

        QMetaObject::connectSlotsByName(inheritance1Class);
    } // setupUi

    void retranslateUi(QWidget *inheritance1Class)
    {
        inheritance1Class->setWindowTitle(QApplication::translate("inheritance1Class", "inheritance1", Q_NULLPTR));
        textEdit->setPlaceholderText(QApplication::translate("inheritance1Class", "\347\202\271\347\232\204\345\235\220\346\240\207\344\270\272\345\257\274\345\207\272\347\232\204\345\215\227\344\272\254\351\203\275\345\270\202\345\234\210\345\233\276\344\270\255\345\203\217\347\264\240\347\232\204\345\235\220\346\240\207", Q_NULLPTR));
        startButton->setText(QApplication::translate("inheritance1Class", "\345\274\200\345\247\213", Q_NULLPTR));
        checkButton->setText(QApplication::translate("inheritance1Class", "\345\257\274\345\207\272\345\215\227\344\272\254\351\203\275\345\270\202\345\234\210\345\233\276", Q_NULLPTR));
        outButton->setText(QApplication::translate("inheritance1Class", "\345\257\274\345\207\272\345\237\272\347\253\231\345\235\220\346\240\207\345\210\260\346\234\254\345\234\260", Q_NULLPTR));
        backButton->setText(QApplication::translate("inheritance1Class", "\350\277\224\345\233\236", Q_NULLPTR));
        label->setText(QApplication::translate("inheritance1Class", "\347\273\223\346\236\234\350\276\223\345\207\272\346\241\206", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class inheritance1Class: public Ui_inheritance1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INHERITANCE1_H
