#pragma once

#include <QMainWindow>
#include "ui_enter1.h"

class enter1 : public QMainWindow
{
	Q_OBJECT

public:
	enter1(QWidget *parent = nullptr);
	~enter1();

private slots:
	void backSlot01();
	void outSlot();

private:
	Ui::enter1Class ui;

signals:
	void clickBack01();
};
