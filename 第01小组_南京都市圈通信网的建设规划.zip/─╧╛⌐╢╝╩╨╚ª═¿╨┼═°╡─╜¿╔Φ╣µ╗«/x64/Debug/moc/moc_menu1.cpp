/****************************************************************************
** Meta object code from reading C++ file 'menu1.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../menu1.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'menu1.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_menu1_t {
    QByteArrayData data[10];
    char stringdata0[102];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_menu1_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_menu1_t qt_meta_stringdata_menu1 = {
    {
QT_MOC_LITERAL(0, 0, 5), // "menu1"
QT_MOC_LITERAL(1, 6, 11), // "clickButton"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 10), // "changeSlot"
QT_MOC_LITERAL(4, 30, 11), // "toEnterSlot"
QT_MOC_LITERAL(5, 42, 10), // "toFindSlot"
QT_MOC_LITERAL(6, 53, 9), // "toCalSlot"
QT_MOC_LITERAL(7, 63, 12), // "toMenuSlot01"
QT_MOC_LITERAL(8, 76, 12), // "toMenuSlot02"
QT_MOC_LITERAL(9, 89, 12) // "toMenuSlot03"

    },
    "menu1\0clickButton\0\0changeSlot\0toEnterSlot\0"
    "toFindSlot\0toCalSlot\0toMenuSlot01\0"
    "toMenuSlot02\0toMenuSlot03"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_menu1[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   54,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   55,    2, 0x08 /* Private */,
       4,    0,   56,    2, 0x08 /* Private */,
       5,    0,   57,    2, 0x08 /* Private */,
       6,    0,   58,    2, 0x08 /* Private */,
       7,    0,   59,    2, 0x08 /* Private */,
       8,    0,   60,    2, 0x08 /* Private */,
       9,    0,   61,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void menu1::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        menu1 *_t = static_cast<menu1 *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clickButton(); break;
        case 1: _t->changeSlot(); break;
        case 2: _t->toEnterSlot(); break;
        case 3: _t->toFindSlot(); break;
        case 4: _t->toCalSlot(); break;
        case 5: _t->toMenuSlot01(); break;
        case 6: _t->toMenuSlot02(); break;
        case 7: _t->toMenuSlot03(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (menu1::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&menu1::clickButton)) {
                *result = 0;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject menu1::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_menu1.data,
      qt_meta_data_menu1,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *menu1::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *menu1::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_menu1.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int menu1::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void menu1::clickButton()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
