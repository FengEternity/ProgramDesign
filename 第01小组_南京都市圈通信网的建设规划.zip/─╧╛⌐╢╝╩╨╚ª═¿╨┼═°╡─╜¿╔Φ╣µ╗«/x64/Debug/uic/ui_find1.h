/********************************************************************************
** Form generated from reading UI file 'find1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIND1_H
#define UI_FIND1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_find1Class
{
public:
    QTextEdit *textEdit;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_4;
    QPushButton *pushButton;
    QPushButton *pushButton_5;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_3;
    QWidget *widget;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_3;
    QLabel *label;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer;
    QComboBox *comboBox_1;
    QComboBox *comboBox_2;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer_5;
    QSpacerItem *horizontalSpacer_6;

    void setupUi(QWidget *find1Class)
    {
        if (find1Class->objectName().isEmpty())
            find1Class->setObjectName(QStringLiteral("find1Class"));
        find1Class->resize(707, 573);
        find1Class->setMinimumSize(QSize(707, 573));
        find1Class->setMaximumSize(QSize(707, 573));
        textEdit = new QTextEdit(find1Class);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(410, 81, 231, 241));
        QFont font;
        font.setPointSize(10);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);
        widget_2 = new QWidget(find1Class);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 330, 481, 171));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        pushButton_4 = new QPushButton(widget_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        QFont font1;
        font1.setPointSize(12);
        pushButton_4->setFont(font1);

        gridLayout_2->addWidget(pushButton_4, 5, 1, 1, 1);

        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setFont(font1);

        gridLayout_2->addWidget(pushButton, 5, 0, 1, 1);

        pushButton_5 = new QPushButton(widget_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setFont(font1);

        gridLayout_2->addWidget(pushButton_5, 3, 0, 1, 2);

        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font1);

        gridLayout_2->addWidget(pushButton_2, 2, 0, 1, 1);

        pushButton_3 = new QPushButton(widget_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setFont(font1);

        gridLayout_2->addWidget(pushButton_3, 2, 1, 1, 1);

        label_3 = new QLabel(find1Class);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(460, 41, 71, 31));
        label_3->setFont(font1);
        widget = new QWidget(find1Class);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 50, 391, 251));
        gridLayout = new QGridLayout(widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 1, 2, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 2, 3, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFont(font1);

        gridLayout->addWidget(label_2, 3, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_3, 5, 3, 1, 1);

        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font1);

        gridLayout->addWidget(label, 1, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 1, 4, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 0, 3, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 1, 0, 1, 1);

        comboBox_1 = new QComboBox(widget);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setFont(font1);

        gridLayout->addWidget(comboBox_1, 1, 3, 1, 1);

        comboBox_2 = new QComboBox(widget);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setFont(font1);

        gridLayout->addWidget(comboBox_2, 3, 3, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 3, 0, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_5, 3, 2, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_6, 3, 4, 1, 1);


        retranslateUi(find1Class);

        QMetaObject::connectSlotsByName(find1Class);
    } // setupUi

    void retranslateUi(QWidget *find1Class)
    {
        find1Class->setWindowTitle(QApplication::translate("find1Class", "find1", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("find1Class", "\345\205\211\347\272\244\346\200\273\351\200\240\344\273\267", Q_NULLPTR));
        pushButton->setText(QApplication::translate("find1Class", "\350\277\224\345\233\236", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("find1Class", "\346\200\273\351\200\240\344\273\267", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("find1Class", "\346\237\245\350\257\242\344\270\244\345\237\216\350\267\235\347\246\273\345\222\214\351\200\240\344\273\267", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("find1Class", "\345\237\272\347\253\231\344\270\252\346\225\260\345\222\214\346\200\273\351\200\240\344\273\267", Q_NULLPTR));
        label_3->setText(QApplication::translate("find1Class", "\350\276\223\345\207\272", Q_NULLPTR));
        label_2->setText(QApplication::translate("find1Class", "\345\237\216\345\270\2022", Q_NULLPTR));
        label->setText(QApplication::translate("find1Class", "\345\237\216\345\270\2021", Q_NULLPTR));
        comboBox_1->clear();
        comboBox_1->insertItems(0, QStringList()
         << QApplication::translate("find1Class", "\345\215\227\344\272\254", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\225\207\346\261\237", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\211\254\345\267\236", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\267\256\345\256\211", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\251\254\351\236\215\345\261\261", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\273\201\345\267\236", Q_NULLPTR)
         << QApplication::translate("find1Class", "\350\212\234\346\271\226", Q_NULLPTR)
         << QApplication::translate("find1Class", "\345\256\243\347\247\260", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\272\247\351\230\263", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\207\221\345\235\233", Q_NULLPTR)
        );
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("find1Class", "\345\215\227\344\272\254", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\225\207\346\261\237", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\211\254\345\267\236", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\267\256\345\256\211", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\251\254\351\236\215\345\261\261", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\273\201\345\267\236", Q_NULLPTR)
         << QApplication::translate("find1Class", "\350\212\234\346\271\226", Q_NULLPTR)
         << QApplication::translate("find1Class", "\345\256\243\347\247\260", Q_NULLPTR)
         << QApplication::translate("find1Class", "\346\272\247\351\230\263", Q_NULLPTR)
         << QApplication::translate("find1Class", "\351\207\221\345\235\233", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class find1Class: public Ui_find1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIND1_H
