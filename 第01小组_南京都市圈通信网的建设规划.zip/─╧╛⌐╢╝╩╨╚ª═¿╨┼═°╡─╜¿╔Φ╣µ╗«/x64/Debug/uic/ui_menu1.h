/********************************************************************************
** Form generated from reading UI file 'menu1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU1_H
#define UI_MENU1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_menu1Class
{
public:
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton;

    void setupUi(QWidget *menu1Class)
    {
        if (menu1Class->objectName().isEmpty())
            menu1Class->setObjectName(QStringLiteral("menu1Class"));
        menu1Class->resize(691, 590);
        menu1Class->setMinimumSize(QSize(691, 590));
        menu1Class->setMaximumSize(QSize(691, 590));
        pushButton_2 = new QPushButton(menu1Class);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(80, 76, 518, 35));
        QFont font;
        font.setPointSize(12);
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(menu1Class);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(80, 193, 518, 35));
        pushButton_3->setFont(font);
        pushButton_4 = new QPushButton(menu1Class);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(80, 427, 518, 35));
        pushButton_4->setFont(font);
        pushButton = new QPushButton(menu1Class);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(80, 310, 518, 35));
        pushButton->setFont(font);

        retranslateUi(menu1Class);

        QMetaObject::connectSlotsByName(menu1Class);
    } // setupUi

    void retranslateUi(QWidget *menu1Class)
    {
        menu1Class->setWindowTitle(QApplication::translate("menu1Class", "menu1", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("menu1Class", "\346\237\245\350\257\242\345\237\216\345\270\202\350\267\235\347\246\273\345\222\214\351\200\240\344\273\267", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("menu1Class", "\350\256\241\347\256\227\345\212\237\350\203\275", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("menu1Class", "\351\200\200\345\207\272", Q_NULLPTR));
        pushButton->setText(QApplication::translate("menu1Class", "\346\237\245\347\234\213\345\215\227\344\272\254\351\203\275\345\270\202\345\234\210\345\270\203\345\261\200", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class menu1Class: public Ui_menu1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU1_H
