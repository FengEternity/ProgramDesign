/********************************************************************************
** Form generated from reading UI file 'Tree.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TREE_H
#define UI_TREE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TreeClass
{
public:
    QWidget *widget_3;
    QGridLayout *gridLayout;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTextEdit *textEdit;
    QSpacerItem *verticalSpacer;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *start;
    QPushButton *pushButton_4;

    void setupUi(QWidget *TreeClass)
    {
        if (TreeClass->objectName().isEmpty())
            TreeClass->setObjectName(QStringLiteral("TreeClass"));
        TreeClass->resize(413, 562);
        TreeClass->setMinimumSize(QSize(413, 562));
        TreeClass->setMaximumSize(QSize(413, 562));
        widget_3 = new QWidget(TreeClass);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(30, 30, 341, 491));
        gridLayout = new QGridLayout(widget_3);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        widget_2 = new QWidget(widget_3);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        verticalLayout = new QVBoxLayout(widget_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        textEdit = new QTextEdit(widget_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        QFont font;
        font.setPointSize(12);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer);

        widget = new QWidget(widget_2);
        widget->setObjectName(QStringLiteral("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        start = new QPushButton(widget);
        start->setObjectName(QStringLiteral("start"));
        start->setFont(font);

        horizontalLayout->addWidget(start);

        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setFont(font);

        horizontalLayout->addWidget(pushButton_4);


        verticalLayout->addWidget(widget);


        gridLayout->addWidget(widget_2, 0, 0, 1, 1);


        retranslateUi(TreeClass);

        QMetaObject::connectSlotsByName(TreeClass);
    } // setupUi

    void retranslateUi(QWidget *TreeClass)
    {
        TreeClass->setWindowTitle(QApplication::translate("TreeClass", "Tree", Q_NULLPTR));
        label->setText(QApplication::translate("TreeClass", "\347\273\223\346\236\234\350\276\223\345\207\272\346\241\206", Q_NULLPTR));
        start->setText(QApplication::translate("TreeClass", "\345\274\200\345\247\213\350\277\220\350\241\214", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("TreeClass", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TreeClass: public Ui_TreeClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TREE_H
