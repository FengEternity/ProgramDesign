/********************************************************************************
** Form generated from reading UI file 'Flo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FLO_H
#define UI_FLO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FloClass
{
public:
    QWidget *centralWidget;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QTextEdit *textEdit;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *inButton;
    QPushButton *searchButton;
    QPushButton *pushButton_2;
    QLabel *label_4;

    void setupUi(QMainWindow *FloClass)
    {
        if (FloClass->objectName().isEmpty())
            FloClass->setObjectName(QStringLiteral("FloClass"));
        FloClass->resize(630, 610);
        FloClass->setMinimumSize(QSize(630, 610));
        FloClass->setMaximumSize(QSize(630, 610));
        centralWidget = new QWidget(FloClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        widget_2 = new QWidget(centralWidget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(90, 60, 451, 451));
        verticalLayout_2 = new QVBoxLayout(widget_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_3 = new QLabel(widget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_2->addWidget(label_3);

        textEdit = new QTextEdit(widget_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        QFont font;
        font.setPointSize(12);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);

        verticalLayout_2->addWidget(textEdit);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_2);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        inButton = new QPushButton(widget_3);
        inButton->setObjectName(QStringLiteral("inButton"));
        inButton->setFont(font);

        horizontalLayout_2->addWidget(inButton);

        searchButton = new QPushButton(widget_3);
        searchButton->setObjectName(QStringLiteral("searchButton"));
        searchButton->setFont(font);

        horizontalLayout_2->addWidget(searchButton);

        pushButton_2 = new QPushButton(widget_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font);

        horizontalLayout_2->addWidget(pushButton_2);


        verticalLayout_2->addWidget(widget_3);

        label_4 = new QLabel(widget_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_2->addWidget(label_4);

        FloClass->setCentralWidget(centralWidget);

        retranslateUi(FloClass);

        QMetaObject::connectSlotsByName(FloClass);
    } // setupUi

    void retranslateUi(QMainWindow *FloClass)
    {
        FloClass->setWindowTitle(QApplication::translate("FloClass", "Flo", Q_NULLPTR));
        label_3->setText(QApplication::translate("FloClass", "\350\276\223\345\207\272\347\273\223\346\236\234\346\241\206", Q_NULLPTR));
        inButton->setText(QApplication::translate("FloClass", "\345\275\225\345\205\245\344\277\241\346\201\257", Q_NULLPTR));
        searchButton->setText(QApplication::translate("FloClass", "\346\237\245\350\257\242\350\267\257\345\276\204", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("FloClass", "\350\277\224\345\233\236", Q_NULLPTR));
        label_4->setText(QApplication::translate("FloClass", "\351\222\210\345\257\271\346\234\211\345\220\221\345\233\276", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FloClass: public Ui_FloClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FLO_H
